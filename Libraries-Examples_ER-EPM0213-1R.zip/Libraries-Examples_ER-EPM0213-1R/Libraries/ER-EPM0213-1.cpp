/***************************************************
/***************************************************
//Web: http://www.buydisplay.com
EastRising Technology Co.,LTD
****************************************************/

#include <stdlib.h>
#include "ER-EPM0213-1.h"

Epd::~Epd() {
};

Epd::Epd() {
    reset_pin = RST_PIN;
    dc_pin = DC_PIN;
    cs_pin = CS_PIN;
    busy_pin = BUSY_PIN;
    width = EPD_WIDTH;
    height = EPD_HEIGHT;
};

int Epd::Init(void) {
    /* this calls the peripheral hardware interface, see epdif */
    if (IfInit() != 0) {
        return -1;
    }
    /* EPD hardware init start */
    Reset();
  /* 
    /////////////////// new EPD
 	SendCommand(0x74);  //Set Analog Block Control
        SendData(0x54);
        SendCommand(0x7E);  //Set Digital Block Control
        SendData(0x3B);
        SendCommand(0x2B);  // Reduce glitch under ACVCOM	
        SendData(0x04);           
        SendData(0x63);
 

	 SendCommand(BOOSTER_SOFT_START_CONTROL);		  // Booster Soft start Control
	SendData(0x8B);		   
	SendData(0x9C);		   
	SendData(0x96);			   
	SendData(0x0F);
 
        
        
	SendCommand(DRIVER_OUTPUT_CONTROL);  // Driver Output control
        SendData(0xD3);           
        SendData(0x00);
        SendData(0x00);     
        
        SendCommand(DATA_ENTRY_MODE_SETTING);  // Data Entry mode setting
        SendData(0x03);         
        SendCommand(SET_RAM_X_ADDRESS_START_END_POSITION); //Set RAM X - address Start / End position
        SendData(0x00); // RAM x address start at 0
        SendData(0x0C); //RAM x address end at 0Ch(12+1)*8->104
        SendCommand(SET_RAM_Y_ADDRESS_START_END_POSITION); //Set Ram Y- address Start / End position
        SendData(0xD3); // RAM y address start at 0D3h;  
        SendData(0x00);
        SendData(0x00); // RAM y address end at 00h;
        SendData(0x00);
        
        
        SendCommand(BORDER_WAVEFORM_CONTROL); // Border Waveform Control
        SendData(0x01); // HIZ


        SendCommand(DISPLAY_UPDATE_CONTROL_1);
        SendData(0x00);//Normal
        
 //       unsigned char temp1,temp2;	
	SendCommand(0x18);//Temperature Sensor Control
	SendData(0x80);  //Internal temperature sensor
	SendCommand(DISPLAY_UPDATE_CONTROL_2);//Display UpdateControl 2
	SendData(0xB1);	//Load Temperature and waveform setting.
	SendCommand(MASTER_ACTIVATION); //Master Activation
	WaitUntilIdle();	   
   */
  
  /////////////////// old EPD
      SendCommand(0x74);
        SendData(0x54);
        SendCommand(0x75);
        SendData(0x3b);
	SendCommand(0x01);		// Set MUX as 212
	SendData(0xD3);
	SendData(0x00);
        SendData(0x00);
	SendCommand(0x3A);		// Set 100Hz
        SendData(0x18);         // Set 120Hz
	SendCommand(0x3B);		// Set 100Hz
	SendData(0x05);         // Set 120Hz
	SendCommand(0x11);		// data enter mode
	SendData(0x03);		///01
	SendCommand(0x44);		// set RAM x address start/end, in page 36
	SendData(0x00);		// RAM x address start at 00h;
	SendData(0x0c);		// RAM x address end at 0fh(12+1)*8->104 
	SendCommand(0x45);		// set RAM y address start/end, in page 37
	SendData(0x00);		
        SendData(0x00);		// RAM y address startat 00h;
	SendData(0xD3);				// RAM y address end at 212
        SendData(0x00);	
	SendData(0x00);		
	SendCommand(0x04);		// set VSH,VSL value
	SendData(0x2D);		// 	    2D13  11v
        SendData(0xb2);		//	    2D13   6v 
        SendData(0x22);		//	    2D13  -11v
       	SendCommand(0x2C);           // vcom
     	SendData(0x50);           //-2.0V     
	SendCommand(0x3C);		// board
	SendData(0x33);		//GS1-->GS1
        SetLut();
      
    return 0;
}

/**
 *  @brief: basic function for sending commands
 */
void Epd::SendCommand(unsigned char command) {
    DigitalWrite(dc_pin, LOW);
    SpiTransfer(command);
}

/**
 *  @brief: basic function for sending data
 */
void Epd::SendData(unsigned char data) {
    DigitalWrite(dc_pin, HIGH);
    SpiTransfer(data);
}

/**
 *  @brief: Wait until the busy_pin goes LOW
 */
void Epd::WaitUntilIdle(void) {
    while(DigitalRead(busy_pin) == HIGH) {      //LOW: idle, HIGH: busy
        DelayMs(100);
    }      
}

/**
 *  @brief: module reset.
 *          often used to awaken the module in deep sleep,
 *          see Epd::Sleep();
 */
void Epd::Reset(void) {
    DigitalWrite(reset_pin, LOW);                //module reset    
    DelayMs(200);
    DigitalWrite(reset_pin, HIGH);
    DelayMs(200);    
}

/**
 *  @brief: set the look-up table register
 */
void Epd::SetLut() {
    SendCommand(WRITE_LUT_REGISTER);
    /* the length of look-up table is 30 bytes */
    for (int i = 0; i < 70; i++) {
        SendData(lut[i]);
    }
}

/**
 *  @brief: put an image buffer to the frame memory.
 *          this won't update the display.
 */
void Epd::SetFrameMemoryBlack(
    const unsigned char* image_buffer,
    int x,
    int y,
    int image_width,
    int image_height
) {
    int x_end;
    int y_end;

    if (
        image_buffer == NULL ||
        x < 0 || image_width < 0 ||
        y < 0 || image_height < 0
    ) {
        return;
    }
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    x &= 0xF8;
    image_width &= 0xF8;
    if (x + image_width >= this->width) {
        x_end = this->width - 1;
    } else {
        x_end = x + image_width - 1;
    }
    if (y + image_height >= this->height) {
        y_end = this->height - 1;
    } else {
        y_end = y + image_height - 1;
    }
    SetMemoryArea(x, y, x_end, y_end);
    /* set the frame memory line by line */
    for (int j = y; j <= y_end; j++) {
        SetMemoryPointer(x, j);
        SendCommand(WRITE_RAM_BW);
        for (int i = x / 8; i <= x_end / 8; i++) {
            SendData(image_buffer[(i - x / 8) + (j - y) * (image_width / 8)]);
        }
    }
 
    
}


/**
 *  @brief: put an image buffer to the frame memory.
 *          this won't update the display.
 */
void Epd::SetFrameMemoryRed(
    const unsigned char* image_buffer,
    int x,
    int y,
    int image_width,
    int image_height
) {
    int x_end;
    int y_end;

    if (
        image_buffer == NULL ||
        x < 0 || image_width < 0 ||
        y < 0 || image_height < 0
    ) {
        return;
    }
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    x &= 0xF8;
    image_width &= 0xF8;
    if (x + image_width >= this->width) {
        x_end = this->width - 1;
    } else {
        x_end = x + image_width - 1;
    }
    if (y + image_height >= this->height) {
        y_end = this->height - 1;
    } else {
        y_end = y + image_height - 1;
    }
    SetMemoryArea(x, y, x_end, y_end);
    /* set the frame memory line by line */
    for (int j = y; j <= y_end; j++) {
        SetMemoryPointer(x, j);
        SendCommand(WRITE_RAM_RED);
        for (int i = x / 8; i <= x_end / 8; i++) {
            SendData(image_buffer[(i - x / 8) + (j - y) * (image_width / 8)]);
        }
    }
 
    
}

/**
 *  @brief: put an image buffer to the frame memory.
 *          this won't update the display.
 *
 *          Question: When do you use this function instead of 
 *          void SetFrameMemory(
 *              const unsigned char* image_buffer,
 *              int x,
 *              int y,
 *              int image_width,
 *              int image_height
 *          );
 *          Answer: SetFrameMemory with parameters only reads image data
 *          from the RAM but not from the flash in AVR chips (for AVR chips,
 *          you have to use the function pgm_read_byte to read buffers 
 *          from the flash).
 */
void Epd::SetFrameMemory(const unsigned char* frame_buffer_black, const unsigned char* frame_buffer_red) {
    SetMemoryArea(0, 0, this->width - 1, this->height - 1);
    /* set the frame memory line by line */
    for (int j = 0; j < this->height; j++) {
        SetMemoryPointer(0, j);
        SendCommand(WRITE_RAM_BW);
        for (int i = 0; i < this->width / 8; i++) {
            SendData(pgm_read_byte(&frame_buffer_black[i + j * (this->width / 8)]));
        }
    }
    
    for (int j = 0; j < this->height; j++) {
        SetMemoryPointer(0, j);
        SendCommand(WRITE_RAM_RED);
        for (int i = 0; i < this->width / 8; i++) {
            SendData(pgm_read_byte(&frame_buffer_red[i + j * (this->width / 8)]));
        }
    }    
    
}

/**
 *  @brief: clear the frame memory with the specified color.
 *          this won't update the display.
 */
void Epd::ClearFrameMemory(void) {
    SetMemoryArea(0, 0, this->width - 1, this->height - 1);
    /* set the frame memory line by line */
    for (int j = 0; j < this->height; j++) {
        SetMemoryPointer(0, j);
        SendCommand(WRITE_RAM_BW);
        for (int i = 0; i < this->width / 8; i++) {
            SendData(0xff);
        }
    }
    for (int j = 0; j < this->height; j++) {
        SetMemoryPointer(0, j);
        SendCommand(WRITE_RAM_RED);
        for (int i = 0; i < this->width / 8; i++) {
            SendData(0x00);
        }
    }    
    
}

/**
 *  @brief: update the display
 *          there are 2 memory areas embedded in the e-paper display
 *          but once this function is called,
 *          the the next action of SetFrameMemory or ClearFrame will 
 *          set the other memory area.
 */
void Epd::DisplayFrame(void) {
    SendCommand(DISPLAY_UPDATE_CONTROL_2);
    SendData(0xC7);
    SendCommand(MASTER_ACTIVATION);
    WaitUntilIdle();
}

/**
 *  @brief: private function to specify the memory area for data R/W
 */
void Epd::SetMemoryArea(int x_start, int y_start, int x_end, int y_end) {
    SendCommand(SET_RAM_X_ADDRESS_START_END_POSITION);
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    SendData((x_start >> 3) & 0xFF);
    SendData((x_end >> 3) & 0xFF);
    SendCommand(SET_RAM_Y_ADDRESS_START_END_POSITION);
    SendData(y_start & 0xFF);
    SendData((y_start >> 8) & 0xFF);
    SendData(y_end & 0xFF);
    SendData((y_end >> 8) & 0xFF);
}

/**
 *  @brief: private function to specify the start point for data R/W
 */
void Epd::SetMemoryPointer(int x, int y) {
    SendCommand(SET_RAM_X_ADDRESS_COUNTER);
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    SendData((x >> 3) & 0xFF);
    SendCommand(SET_RAM_Y_ADDRESS_COUNTER);
    SendData(y & 0xFF);
    SendData((y >> 8) & 0xFF);
    WaitUntilIdle();
}

/**
 *  @brief: After this command is transmitted, the chip would enter the 
 *          deep-sleep mode to save power. 
 *          The deep sleep mode would return to standby by hardware reset. 
 *          You can use Epd::Init() to awaken
 */
void Epd::Sleep() {
    SendCommand(DEEP_SLEEP_MODE);
    SendData(0x01);    
    WaitUntilIdle();
}

const unsigned char lut[] =
{
0xAA,	0x99,	0x10,	0x00,	0x00,	0x00,	0x00,	0x55,	0x99,	0x80,	0x00,	0x00,	0x00,	0x00,	0x8A,	0xA8,
0x9B,	0x00,	0x00,	0x00,	0x00,	0x8A,	0xA8,	0x9B,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,
0x00,	0x00,	0x00,	0x0F,	0x0F,	0x0F,	0x0F,	0x02,	0x14,	0x14,	0x14,	0x14,	0x06,	0x14,	0x14,	0x0C,
0x82,	0x08,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,
0x00,	0x00,	0x00,	0x00,	0x00,	0x00,									

/*
0xA5,	0x89,	0x10,	0x00,	0x00,	0x00,	0x00,	0xA5,	0x19,	0x80,	0x00,	0x00,	0x00,	0x00,	0xA5,	0xA9,
0x9B,	0x00,	0x00,	0x00,	0x00,	0xA5,	0xA9,	0x9B,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,
0x00,	0x00,	0x00,	0x0F,	0x0F,	0x0F,	0x0F,	0x02,	0x10,	0x10,	0x0A,	0x0A,	0x03,	0x08,	0x08,	0x09,
0x43,	0x07,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,	0x00,
0x00,	0x00,	0x00,	0x00,	0x00,	0x00,										
 */
	
};

/* END OF FILE */


